def log(message):
    """Logger for packaage. Prints the string with additional information.

        :param message: Message to print
        :type message: str
    """
    print("[PoseUtils] " + message)